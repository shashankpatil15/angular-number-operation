# angular-number-operations
Binding number operations and colors using interpolation
